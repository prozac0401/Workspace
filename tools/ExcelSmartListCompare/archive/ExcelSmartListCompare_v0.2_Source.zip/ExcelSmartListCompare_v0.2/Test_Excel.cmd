@echo off
setlocal
(
  powershell.exe -NoLogo -NoProfile -STA -File "%~dp0Setup.ps1" -Action Test
  echo.
  pause
)
